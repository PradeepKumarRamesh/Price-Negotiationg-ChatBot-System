﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-11MK4VT;Initial Catalog=priceNegotiate;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        string uid =(string) Session["uid"];
        string sel1 = "select count(pid) from cart where  uid='"+uid+"'";
        SqlDataAdapter sda = new SqlDataAdapter(sel1, con);
        DataSet ds = new DataSet();
        sda.Fill(ds);

        Label1.Text = ds.Tables[0].Rows[0][0].ToString();
             
    }
}
