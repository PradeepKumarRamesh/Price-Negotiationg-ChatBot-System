﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class viewOrders : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-11MK4VT;Initial Catalog=priceNegotiate;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        string sel = "select * from orders";
        SqlDataAdapter sda = new SqlDataAdapter(sel, con);
        DataSet ds = new DataSet();
        sda.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}